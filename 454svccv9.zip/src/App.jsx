import { useState } from "react";
import "./App.css";

function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [page, setPage] = useState("overview");

  // LOGIN PAGE
  if (!loggedIn) {
    return (
      <>
        <nav className="navbar">
          <h2>Student Portal</h2>

          <div>
            <span>Home</span>
            <span>Courses</span>
            <button onClick={() => setLoggedIn(true)}>
              Login
            </button>
          </div>
        </nav>

        <div className="login-container">
          <div className="login-card">
            <h1>Student Login</h1>
            <p>Login to access your student dashboard.</p>

            <button
              className="blue-btn"
              onClick={() => setLoggedIn(true)}
            >
              Login
            </button>
          </div>
        </div>
      </>
    );
  }

  // DASHBOARD
  return (
    <>
      <nav className="navbar">
        <h2>Student Portal</h2>

        <div>
          <span>Home</span>
          <span>Courses</span>

          <button
            className="dashboard-btn"
            onClick={() => setPage("overview")}
          >
            Dashboard
          </button>

          <button
            className="logout-btn"
            onClick={() => setLoggedIn(false)}
          >
            Logout
          </button>
        </div>
      </nav>

      <main className="dashboard">

        <h1>Student Dashboard</h1>
        <p className="subtitle">
          Manage your student account.
        </p>

        {/* THREE PAGES / TABS */}
        <div className="tabs">

          <button
            className={page === "overview" ? "active" : ""}
            onClick={() => setPage("overview")}
          >
            Overview
          </button>

          <button
            className={page === "profile" ? "active" : ""}
            onClick={() => setPage("profile")}
          >
            Profile
          </button>

          <button
            className={page === "settings" ? "active" : ""}
            onClick={() => setPage("settings")}
          >
            Settings
          </button>

        </div>

        {/* OVERVIEW */}
        {page === "overview" && (
          <div className="content-card">

            <h2>Dashboard Overview</h2>

            <div className="cards">

              <div className="stat-card">
                <h3>4</h3>
                <p>Enrolled Courses</p>
              </div>

              <div className="stat-card">
                <h3>82%</h3>
                <p>Average Progress</p>
              </div>

              <div className="stat-card">
                <h3>12</h3>
                <p>Assignments</p>
              </div>

            </div>

          </div>
        )}

        {/* PROFILE */}
        {page === "profile" && (
          <div className="content-card">

            <h2>Student Profile</h2>

            <div className="profile">

              <p>
                <b>Name:</b>sai pradeep
              </p>

              <p>
                <b>Student ID:</b> 536
              </p>

              <p>
                <b>Email:</b> student@example.com
              </p>

              <p>
                <b>Department:</b> Computer Science & Engineering
              </p>

              <p>
                <b>Year:</b> Final Year
              </p>

            </div>

            <button className="blue-btn">
              Edit Profile
            </button>

          </div>
        )}

        {/* SETTINGS */}
        {page === "settings" && (
          <div className="content-card">

            <h2>Settings</h2>

            <div className="setting">
              <div>
                <h3>Email Notifications</h3>
                <p>Receive course and assignment updates.</p>
              </div>

              <input type="checkbox" defaultChecked />
            </div>

            <div className="setting">
              <div>
                <h3>Dark Mode</h3>
                <p>Change dashboard appearance.</p>
              </div>

              <input type="checkbox" />
            </div>

            <h3>Change Password</h3>

            <input
              className="input"
              type="password"
              placeholder="New Password"
            />

            <br />

            <button className="blue-btn">
              Save Changes
            </button>

          </div>
        )}

      </main>
    </>
  );
}

export default App;
